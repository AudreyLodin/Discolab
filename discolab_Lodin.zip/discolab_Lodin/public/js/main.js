var socket = io();
var usrStore;
var groupe=[];
var salonStore;
var appStore={};
appStore.version="1.0";
var numeroligne;
var online=false;
const inscrire = document.querySelector('#inscription');
const connecter = document.querySelector('#connexion');
const accueil = document.querySelector('#menu');
var change = 0;

const editor = CodeMirror.fromTextArea(document.getElementById("creerfichier"), {
    mode: "python",
    theme: "monokai",
    lineNumbers: false,
});

function Inscription(){
    inscrire.style.display='flex';
    connecter.style.display='none';
    accueil.style.display='none';
    appStore.location={"page":"accueil","mode":"ins"};
    localStorage.setItem("app",JSON.stringify(appStore));
}
function connect(){
    inscrire.style.display='none';
    connecter.style.display='flex';
    accueil.style.display='none';
    appStore.location={"page":"accueil","mode":"con"};
    localStorage.setItem("app",JSON.stringify(appStore));
}
function inscrit(){
    const nom = document.querySelector('#inom').value;
    const prenom = document.querySelector('#iprenom').value;
    const email = document.querySelector('#iemail').value;
    const pwd = document.querySelector('#pwd').value;
    const cpwd = document.querySelector('#cpwd').value;
    if(nom && prenom && email && pwd && cpwd){
        if(pwd === cpwd){
            insc(prenom,nom,email,pwd);
        }
    }
}
async function insc(prenom,nom,email,pwd){
    await fetch('/inscription',{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prenom: prenom, nom: nom, email: email, pwd: pwd })
    }).then(response => response.json())
    .then(data => {
        if(data.success){
            inscrire.style.display='none';
            connecter.style.display='flex';
            accueil.style.display='none';

        }else{
            document.querySelector('#erreur1').style.display='flex';
            document.querySelector('#erreur1').style.color='red';
            document.querySelector('.input-con input').style.color='red';
            setTimeout(() =>{
                document.querySelector('#erreur1').style.display='none';
                document.querySelector('#erreur1').style.color='white';
                document.querySelector('.input-con input').style.color='white';
            },7000);
        }
    })
    .catch(error => {
        document.querySelector('#erreur1').style.display='flex';
        document.querySelector('#erreur1').style.color='red';
        document.querySelector('.input-con input').style.color='red';
        setTimeout(() =>{
            document.querySelector('#erreur1').style.display='none';
            document.querySelector('#erreur1').style.color='white';
            document.querySelector('.input-con input').style.color='white';
        },7000);
    });
}
async function Connexion() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    await fetch('/connexion', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email: email, password: password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            var usr=data.info;
            usrStore=usr;
            menu();
            //console.log(usr);
            //localStorage.setItem("user",JSON.stringify(usr));
            // Afficher le prénom de l'utilisateur
            //document.getElementById('message').innerHTML = `Bienvenue, ${data.info.prenom}!`;
            //document.querySelector('#connexion').style.display='none';
            //document.querySelector('#menu').style.display='flex';
        } else {
            document.querySelector('#erreur').style.display='flex';
            document.querySelector('#erreur').style.color='red';
            document.querySelector('.input-con input').style.color='red';
            setTimeout(() =>{
                document.querySelector('#erreur').style.display='none';
                document.querySelector('#erreur').style.color='white';
                document.querySelector('.input-con input').style.color='white';
            },7000);
        }
        /*
        console.log(data.success)
        if(data.success==false){
            document.querySelector('#erreur').style.display='flex';
        }*/
    })
    .catch(error => {
        document.querySelector('#erreur').style.display='flex';
        document.querySelector('#erreur').style.color='red';
        document.querySelector('.input-con input').style.color='red';
        setTimeout(() =>{
            document.querySelector('#erreur').style.display='none';
            document.querySelector('#erreur').style.color='white';
            document.querySelector('.input-con input').style.color='white';
        },7000);
    });
    /*
    console.log(usrStore.id);
    var idsal=usrStore.id;
    desalon(idsal);
    online=true;
            
    const liste = {
        online: online,
        id: usrStore.id,
        nom: usrStore.nom,
        prenom: usrStore.prenom
    }
    console.log(liste);
    socket.emit('online',liste);
    localStorage.setItem("user",JSON.stringify(usrStore));*/
}



async function user(){
    var data;
    await fetch('/utilisateur', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify()
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            data.info.forEach(user => {
                if(usrStore.nom != user.nom && usrStore.prenom != user.prenom){
                    document.querySelector('#user').innerHTML+=`<div class="boutonuser" id="${user.id}" onclick="tabgroupe(${user.id})"><div class="prenom">${user.prenom}</div><div class="nom">${user.nom}</div></div>`;
                }
                
            });
            // Afficher le prénom de l'utilisateur
            //document.getElementById('message').innerHTML = `Bienvenue, ${data.info.prenom}!`;
            
        } else {
            // Afficher le message d'erreur
            return false;
        }
    })
    .catch(error => {
        console.error('Erreur de connexion :', error);
    });
    changement();
}

async function desalon(idsal){
    //var data=usrStore.id;
    document.querySelector('.salon.liste').innerHTML=``;
    let doc1 = document.querySelector('.pseudo.salon');
    let doc = document.querySelector('.salon.liste');
    doc.innerHTML='';
    doc1.innerHTML='';
    await fetch('/allsalon', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({id: idsal})
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.querySelector('.salon.liste').innerHTML=``;
            //console.log(data);
            data.info.forEach(sal => {
                //salonStore=sal;
                //console.log(sal.admin);
                if(sal.admin==usrStore.id){
                    doc.innerHTML+=`<div class="block-salon"><div class="boutonsalon" id="${sal.id}" onclick="affichechat(${sal.id},'${sal.descricption}')"><div class="nom">${sal.descricption}</div></div><div class="bar icon" onclick="verifsupsalon(${sal.id})"><i class="fa-solid fa-trash"></i></div></div>`;
                }else{
                    doc.innerHTML+=`<div class="boutonsalon" id="${sal.id}" onclick="affichechat(${sal.id},'${sal.descricption}')"><div class="nom">${sal.descricption}</div></div>`;
                }
                
                
            })
            // Afficher le prénom de l'utilisateur
            //document.getElementById('message').innerHTML = `Bienvenue, ${data.info.prenom}!`;
            
        } else {
            // Afficher le message d'erreur
            return false;
        }
        
    })
    .catch(error => {
        //console.error('Erreur de connexion :', error);
        return false;
    });
    doc1.innerHTML=`<div class="decon" onclick="useronline()"><i class="fa-solid fa-users-line"></i></div><div class="pseudo">${usrStore.prenom} ${usrStore.nom}</div><div class="decon" onclick="deconnex()"><i class="fa-solid fa-right-from-bracket"></i></div>`;
    changement();
    return true;
}

async function verifsupsalon(id){
    await fetch('/suppressionsalon', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: id })
    })
    .then(response => response.json())
    .then(data => {
    })
    .catch(error => {
    });
    desalon(usrStore.id);
    changement();
}

function tabgroupe(i){
    groupe.push(i);
    //console.log(groupe);
    document.querySelector('.infosalon').style.display='flex';
    return groupe;
    changement();
}

function useronline(){
    const l =document.querySelector('.online').style.display;
    if(l=='flex'){
        document.querySelector('.online').style.display='none';
    }else{
        document.querySelector('.online').style.display='flex';
    }
    changement();
}



async function affichageuser(){
    var datas = await user();
    //console.log(datas);
    if(datas!=false){
        datas.forEach(data => {
            document.querySelector('#user').innerHTML+=`<div class="boutonuser"><div class="prenom">${data.prenom}</div><div class="nom">${data.nom}</div></div>`;
        });
    }
    changement();
}

async function menu(){
    //await Connexion();
    //user();
    //console.log(usr);
    accueil.style.display='flex';
    connecter.style.display='none';
    inscrire.style.display='none';
    //console.log(usrStore.id);
    var idsal=usrStore.id;
    desalon(idsal);
    online=true;
            
    const liste = {
        online: online,
        id: usrStore.id,
        nom: usrStore.nom,
        prenom: usrStore.prenom
    }
    //console.log(usrStore);
    socket.emit('online',{
        online: online,
        id: usrStore.id,
        nom: usrStore.nom,
        prenom: usrStore.prenom
    });
    localStorage.setItem("user",JSON.stringify(usrStore));
    appStore.location={"page":"menu","mode":"salon"};
    localStorage.setItem("app",JSON.stringify(appStore));
    //localStorage.setItem("user",JSON.stringify(usrStore));
    //console.log(localStorage.getItem("user"));
    //console.log(JSON.parse(localStorage.getItem("user")));
    changement();
}

async function usermembre(nombre){
    var data;
    let email;
    document.querySelector('.usermembre').innerHTML='';
    if(nombre==0){
        document.querySelector('.infosalon').style.display='none';
        document.querySelector('.usermembre').innerHTML='';
        email = document.querySelector('#membre').value;
    }else{
        document.querySelector('.ajoutusermembre').innerHTML='';
        email = document.querySelector('#ajoutmembre').value;
    }
    
    await fetch('/search', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.info);
        if (data.success) {
            data.info.forEach(user => {
                if(usrStore.nom != user.nom || usrStore.prenom != user.prenom){
                    console.log(1);
                    if(nombre==0){
                        document.querySelector('.usermembre').innerHTML+=`<div class="boutonuser" id="${user.id}" onclick="tabgroupe(${user.id})"><div class="prenom">${user.prenom}</div><div class="nom">${user.nom}</div></div>`;
                    }else{
                        document.querySelector('.ajoutusermembre').innerHTML+=`<div class="boutonuser" id="${user.id}" onclick="tabgroupe(${user.id})"><div class="prenom">${user.prenom}</div><div class="nom">${user.nom}</div></div>`;
                    }
                    
                }
                
            });
            // Afficher le prénom de l'utilisateur
            //document.getElementById('message').innerHTML = `Bienvenue, ${data.info.prenom}!`;
            
        } else {
            // Afficher le message d'erreur
            return false;
        }
    })
    .catch(error => {
        //console.error('Erreur de connexion :', error);
    });
    changement();
    
}

function grp(){
    document.querySelector('#createsalon').style.display='flex';
}

function createsalon(){
    const s =document.querySelector('.ajoutsalon');
    groupe=[];
    if(s.style.display==='flex'){
        s.style.display='none';
        document.querySelector('.infosalon').style.display='none';
    }else{
        s.style.display='flex';
    }
    changement();
}

function formatDate() {
    var d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}

function changcolor(){
    const couleur = document.querySelector('.ajout.color');
    if(couleur.style.display=='flex'){
        couleur.style.display='none';
    }else{
        couleur.style.display='flex';
    }
}

function changcolornoir(){
    change=0;
    const couleur = document.querySelector('.ajout.color');
    const elements = document.querySelectorAll('*');
    elements.forEach(element=>{
        /*
        if(background==='rgb(255, 240, 230)'){
            //element.style.backgroundColor='rgb(30, 33, 36)';
            background='rgb(30, 33, 36)';
        }*/
            
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(230, 230, 230)'){
            element.style.backgroundColor='rgb(54, 57, 62)';
        }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(240, 240, 240)'){
            element.style.backgroundColor='rgb(30, 33, 36)';
       }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(255,255, 255)'){
            element.style.backgroundColor='rgb(0, 0, 0)';
        }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(220, 220, 220)'){
            element.style.backgroundColor='rgb(46, 52, 64)';
        }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(210, 210, 210)'){
            element.style.backgroundColor='rgb(51, 51, 51)';
        }
    });
    document.querySelectorAll('*').forEach(element => {
        element.style.color = 'white';
    });
    //document.querySelector('span.cm-variable').style.color='white';
    //='rgb(0,0,0)';
    couleur.style.display='none';
    //document.querySelector('span.cm-variable').style.color='white';
}

function changcolorwhite(){
    change=1;
    const couleur = document.querySelector('.ajout.color');
    const elements = document.querySelectorAll('*');
    elements.forEach(element=>{
        /*
        if(background==='rgb(30, 33, 36)'){
            //element.style.backgroundColor='rgb(255, 240, 230)';
            background='rgb(255, 240, 230)';
        }*/
       if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(30, 33, 36)'){
            element.style.backgroundColor='rgb(240, 240, 240)';
       }
       if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(0, 0, 0)'){
            element.style.backgroundColor='rgb(255,255, 255)';
        }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(54, 57, 62)'){
            element.style.backgroundColor='rgb(230, 230, 230)';
        }
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(46, 52, 64)'){
            element.style.backgroundColor='rgb(220, 220, 220)';
        }
        
        if(window.getComputedStyle(element).getPropertyValue("background-color")=='rgb(51, 51, 51)'){
            element.style.backgroundColor='rgb(210, 210, 210)';
        }
    });
    document.querySelectorAll('*').forEach(element => {
        element.style.color = 'black';
    });
    //document.querySelector('span.cm-variable').style.color='black';
    //='rgb(255,255,255)';
    couleur.style.display='none';
    //document.querySelector('span.cm-variable').style.color='black';
}

function changement(){
    if(change==1){
        changcolorwhite();
    }else{
        changcolornoir();
    }
}



async function membre(idsalon,idpers,role){
    let date = formatDate();
    await fetch('/membre', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ personne: idpers, salon: idsalon, role: role, date : date })
    })
    .then(response => response.json())
    .then(data => {
    })
    .catch(error => {
        //console.error('Erreur de creation de membre :', error);
    });
    changement();
    //console.log(usrStore);
}

async function envoiMail(idpers,desc){
    let date = formatDate();
    await fetch('/mail', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: idpers })
    })
    .then(response => response.json())
    .then(data => {
        Email.send({
            SecureToken: "VOTRE_SECURE_TOKEN", // Utilisez le SecureToken généré
            To: to,
            From: "votre_email@example.com", // L'adresse e-mail utilisée pour générer le SecureToken
            Subject: subject,
            Body: message
        });
    })
    .catch(error => {
        //console.error('Erreur de creation de mail :', error);
    });
    //console.log(usrStore);
}


async function creerSalon(){
    //console.log(usrStore);
    document.querySelector('.ajoutsalon').style.display='none';
    const id= usrStore.id;
    const desc = document.getElementById('desc').value;
    const type = document.getElementById('type').value;
    //socket.emit('invite',{salon:{nom: desc , id: 1} , groupe: groupe });
    
    await fetch('/salon', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: id, desc: desc, type: type })
    })
    .then(response => response.json())
    .then(data => {
        //groupe.push(usrStore.id);
        membre(data.id,usrStore.id,"administrateur");
        //console.log(groupe,data.id);
        socket.emit('invite',{salon:{nom: desc , id: data.id} , groupe: groupe });
        /*
        groupe.forEach(grp =>{
            if(grp==usrStore.id){
                const role = 'adminstrateur';
                membre(data.id,grp,role);
            }else{
                const role = 'utilisateur';
                membre(data.id,grp,role);
            }
            console.log(grp);
            
        });*/
    })
    .catch(error => {
        //console.error('Erreur de création de salon :', error);
    });
    groupe=[];
    desalon(id);
    changement();
}
socket.on('invite',(data)=>{
    //console.log(data.groupe, data.salon);
    data.groupe.forEach(grp=>{
        if(grp==usrStore.id){
            const inv =  document.querySelector('.invitation');
            inv.style.display='flex';
            inv.innerHTML=`<div class="rejoint"><div class="text-rejoint">Rejoindre le groupe ${data.salon.nom}</div>
            <div class="choix"><div class="button oui" onclick="choixinvite(1,${data.salon.id})">Oui</div>
                    <div class="button non" onclick="choixinvite(2,${data.salon.id})">Non</div></div></div>`;
            //console.log("invitation "+data.salon.nom+" a rejoindre le groupe");
        }
    })
    menu();
    changement();
});
function choixinvite(nb,id){
    console.log(id);
    if(nb==1){
        socket.emit('stop invite',usrStore.id);
        menu();
        //console.log("yes tu as dit oui");
        membre(id,usrStore.id,"utilisateur");
    }else{
        socket.emit('stop invite',usrStore.id);
        //console.log("Non tu as dit non");
    }
    const inv =  document.querySelector('.invitation');
    inv.innerHTML='';
    changement();
}
socket.on('stop invite',data=>{
    menu();
    changement();
    //document.querySelector('.bar.salon').innerHTML='';
});
/***********************************************************************/
//Partie chat
/***********************************************************************/
/*
if(salonStore.length>0){
    socket.emit('load chat',salon);
}*/
async function usersalon(idsalon,nombre){
    const mem = document.querySelector('.salonmembre');
    mem.innerHTML='';
    await fetch('/allmembre', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ idsalon: idsalon })
    })
    .then(response => response.json())
    .then(data => {
        if(nombre==0){
            for(let i=0;i<data.info.length;i++){
                if(i==(data.info.length-1)){
                    if(usrStore.id==data.info[i].id){
                        mem.innerHTML+=`Vous`;
                    }else{
                        mem.innerHTML+=`${data.info[i].prenom} ${data.info[i].nom}`;
                    }
                    
                }else{
                    if(usrStore.id==data.info[i].id){
                        mem.innerHTML+=`Vous,`;
                    }else{
                        mem.innerHTML+=`${data.info[i].prenom} ${data.info[i].nom},`;
                    }
                }
                
            } 
        }
        
        /*
        data.info.forEach((memb)=>{
            if(memb.id!=usrStore.id){
                mem.innerHTML+=`<div class="salon membre">${memb.prenom} ${memb.nom}</div>`;
            }
            
        });*/
    })
    .catch(error => {
        //console.error('Erreur de creation de mail :', error);
    });
    //console.log(usrStore);
    changement();
}

async function newmembre(){
    document.querySelector('.ajout.membre').style.display='none';
    socket.emit('invite',{salon: {nom: salonStore.desc, id: salonStore.id} , groupe: groupe });
    groupe.forEach(grp =>{
        //console.log(grp);
        //membre(salonStore.id,grp);
    });
    groupe=[];
    usersalon(salonStore.id,0);
    changement();
}

async function quitsalon(personne,salon){
    await fetch('/suppressionmembre', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ personne: personne, salon: salon })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success==true){
            desalon(usrStore.id);
            document.querySelector('.bar.salon').innerHTML='';
            document.querySelector('#zonefichier').innerHTML='';
            document.querySelector('.block-message').innerHTML='';
            //document.querySelector('#creerfichier').value='';
            editor.setValue(" ");
        }
    })
    .catch(error => {
        //console.error('suppression : ', error);
    });
    changement();
}

function verifquit(personne,salon){
    const pop1 = document.querySelector('.popup.delete');
    pop1.style.display='flex';

    const non = document.querySelector('.button.non');
    const oui = document.querySelector('.button.oui');
    

    non.addEventListener("click", (event) => {
        pop1.style.display='none';
    });
    oui.addEventListener("click", (event) => {
        pop1.style.display='none';
        quitsalon(personne,salon);
    });
    changement();
}

async function affichechat(idsal,descsal){
    
    const bar = document.querySelector('.bar.salon');
    document.querySelector('#senMessage').style.display='flex';
    document.querySelector('.bar-fichier').style.display='flex';
    const zonetexte = editor;
    const save = document.querySelector('.block-bouton');
    document.querySelector('.fichier.nom').style.display='none';
    document.querySelector('.fichier.nom').innerHTML=``;
    save.innerHTML=``;
    zonetexte.setValue("");
    bar.innerHTML='';
    
    salonStore={
        id : idsal,
        desc : descsal
    };
    document.querySelector('#chat').style.display='flex';
    await fetch('/rolemembre', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idper: usrStore.id, idsalon: idsal })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success==true){
            //console.log(data.info.role);
            if(data.info.admin==usrStore.id){
                bar.innerHTML=`<div class="bar nom">${salonStore.desc}</div><div class="salonmembre"></div><div class="content popup2"><div class="bar icon" onclick="affichemembre()"><i class="fa-solid fa-user-plus"></i></div></div>
                <div class="bar icon" onclick="verifquit(${usrStore.id},${salonStore.id})"><i class="fa-solid fa-person-walking-arrow-right"></i></div>`;
                document.querySelector('.content.popup2').innerHTML+=`<div class="ajout membre" style="display: none;">
                    <div class="search">
                        <input type="text" id="ajoutmembre" name="ajoutmembre" placeholder="Ajouter un membre" required>
                        <div class="bar icon" onclick="usermembre(1)"><i class="fa-solid fa-magnifying-glass"></i></div>
                    </div>
                    <div class="ajoutusermembre"></div>
                    <div class="bouton" onclick="newmembre()">Nouveau membre</div>
                </div>`;
            }else{
                bar.innerHTML=`<div class="bar nom">${salonStore.desc}</div><div class="salonmembre"></div>
                <div class="bar icon" onclick="verifquit(${usrStore.id},${salonStore.id})"><i class="fa-solid fa-person-walking-arrow-right"></i></div>`;
            }
        }
        return false;
    });
    //console.log(salonStore)
    
    usersalon(salonStore.id,0);
    bar.style.borderBottom='.1rem solid rgb(74,74,74)';
    socket.emit('load chat',salonStore.id);
    await listfichier();
    changement();
    /*
    socket.on('online',(ligne)=>{
    
    ligne.forEach(lig =>{
        console.log(lig);
        console.log(desalon(lig.id));
        //document.querySelector('.block.pers').innerHTML+=`<div>${}</div>`;
    });
    console.log(ligne);
    
    });*/
}

function affichemembre(){
    groupe=[];
    const ajout = document.querySelector('.ajout.membre');
    if(ajout.style.display=='flex'){
        ajout.style.display='none';
    }else{
        ajout.style.display='flex';
    }
    changement();
}

async function membresalon(idpers1,idpers2){
    await fetch('/perssalon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idpers1: idpers1, idpers2: idpers2 })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Réponse du serveur:', data);
        if(data.success==true){
            return true;
        }
        return false;
    });/*
    .catch(error => {
        console.error('Erreur de création de fichier :', error);
        return false;
    });*/
    changement();

} 

socket.on('numero',(num)=>{
    numeroligne=num;
    //console.log(numeroligne);

});

async function connecte(ligne){
    const enligne = document.querySelector('.block.pers');
    enligne.innerHTML='';
    //console.log(ligne);
    for(let i = 0 ; i < ligne.length ; i++){
        //ligne[i].id!=ligne[numeroligne].id || 
        //console.log(usrStore.id)
        if(ligne[i].id!=usrStore.id){
            await fetch('/perssalon', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idpers1: usrStore.id, idpers2: ligne[i].id })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Réponse du serveur:', data);
                if(data.success==true){
                    enligne.innerHTML+=`<div class="pers online">${ligne[i].prenom} ${ligne[i].nom}</div>`;
                }
                return false;
            });
            /*
            .catch(error => {
                console.error('Erreur de création de fichier :', error);
                return false;
            });*/
            /*
            if(membresalon(ligne[numeroligne].id,ligne[i].id)==true){
                enligne.innerHTML+=`<div class="pers online">${ligne[i].prenom} ${ligne[i].nom}</div>`;
            }*/
            
        }
        
    }
    changement();
}

socket.on('online', async (ligne)=>{
    /*
    ligne.forEach(lig =>{
        console.log(lig);
        console.log(desalon(lig.id));
        //document.querySelector('.block.pers').innerHTML+=`<div>${}</div>`;
    });*/
    connecte(ligne);
    changement();
});

socket.on('membre ecrit',(data)=>{
    if(data.salon==salonStore.id){
        document.querySelector('.ecrire').innerHTML=`${data.prenom} ${data.nom} est en train d'écrire...`;
        document.querySelector('.ecrire').style.display='block';
        changement();
    }
    
});
let taper = false;
let temps;
const ecritmessage = document.querySelector('#sendmsg');
ecritmessage.addEventListener('input', ()=>{
    if(!taper){
        taper=true;
        const usrecrit ={
            nom: usrStore.nom,
            id: usersalon.id,
            prenom: usrStore.prenom,
            salon: salonStore.id
        };
        socket.emit('ecrit',usrecrit);
    }
    clearTimeout(temps);
    temps = setTimeout(() =>{
        taper=false;
        const usrecrit ={
            nom: usrStore.nom,
            id: usersalon.id,
            prenom: usrStore.prenom,
            salon: salonStore.id
        };
        socket.emit('stop ecrit',usrecrit);
    },10000);
    changement();
});

socket.on('stop membre',(data)=>{
    document.querySelector('.ecrire').innerHTML+=``;
    document.querySelector('.ecrire').style.display='none';
    changement();
});

socket.on('desconnect', async (ligne)=>{
    connecte(ligne);
    changement();
});

socket.on('historique chat',(msg)=>{
    const block = document.querySelector('.block-message');
    block.innerHTML='';
    msg.forEach(message=>{
        affichemsg1(message);
    });
    changement();
});

socket.on('recevoir message', (msg)=>{
    if(msg.salon==salonStore.id){
        affichemsg1(msg);
        changement();
    }
    
});

async function savef(nom) {
    //const contenu = document.querySelector('textarea#creerfichier').value;
    if(document.querySelector('.create-file').style.display=='flex'){
        document.querySelector('.create-file').style.display=`none`;
        nom = document.querySelector('input#file').value;
        const extension = document.querySelector('input#extension').value;
        if(nom && extension){
            Enfichier(nom,extension);
            nom = nom.concat('.'.concat(extension));
        }
    }
    console.log(nom);
    const contenu = editor.getValue();
    if(nom || nom!='non'){
        console.log(1);
        await fetch('/save-file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nom: nom, contenu: contenu })
        })
        .then(response => response.json())
        .then(data => {
            listfichier();
            console.log(2);
            console.log('Réponse du serveur:', data);
        })
        .catch(error => {
            console.error('Erreur de création de fichier :', error);
        });
    }
    //listfichier();
    changement();
}


async function openf(nom){
    //const text = document.querySelector('#creerfichier');
    const text = editor;
    document.querySelector('.fichier.nom').style.display='flex';
    document.querySelector('.fichier.nom').innerHTML=`${nom}`;
    text.innerHTML='';
    document.querySelector('.block-bouton').innerHTML='';
    console.log(nom);
    try {
        const response = await fetch('/read-file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nom })
        });

        if (!response.ok) {
            const error = await response.json();
            return;
        }
        const data = await response.json();
        //text.innerHTML+=data.content;
        editor.setValue(data.content);
        editor.innerHTML=data.content;
        //text.innerHTML+=data.content;
    } catch (err) {
        
    }
    document.querySelector('.block-bouton').innerHTML+=`<div class="savebutton"><div class="text icon"><i class="fa-regular fa-floppy-disk"></i></div><div class="text save" onclick="savef('${nom}')">Enregistrer</div></div>`;
    if(nom.toString().split('.').pop()=='py'){
        document.querySelector('.block-bouton').innerHTML+=`<div class="savebutton"><div class="text icon"><i class="fa-solid fa-terminal"></i></div><div class="text save" onclick="compiler('${nom}')">Run Python</div></div>`;
    }
    await listfichier();
    changement();
}

async function supfichier(id){
    await fetch('/suppressionfichier', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: id })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success==true){
            listfichier();
        }
    });
    const zonetexte = editor;
    const save = document.querySelector('.block-bouton');
    document.querySelector('.fichier.nom').style.display='none';
    document.querySelector('.fichier.nom').innerHTML=``;
    save.innerHTML=``;
    zonetexte.setValue("");
    /*
    .catch(error => {
        console.error('suppression : ', error);
    });*/
    changement();
}

async function supnomfichier(nom){
    await fetch('/sup-file', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nom: nom })
    })
    .then(response => response.json())
    .then(data => {
    });
    /*
    .catch(error => {
        console.error('suppression : ', error);
    });*/
    changement();
}

function verifsupfichier(id,nom){
    const pop1 = document.querySelector('.popup.delete');
    pop1.style.display='flex';

    const non = document.querySelector('.button.non');
    const oui = document.querySelector('.button.oui');
    

    non.addEventListener("click", (event) => {
        pop1.style.display='none';
    });
    oui.addEventListener("click", (event) => {
        pop1.style.display='none';
        supfichier(id);
        supnomfichier(nom);
    });
    changement();
}

async function propfichier() {
    const response = await fetch('/propfichier', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ idprop: usrStore.id, idsalon: salonStore.id })
    });

    const data = await response.json();

    if (data.success) {
        return data.info; 
    } else{
        return [];
    }
    changement();
}

function nouveaufichier(){
    //const zonetexte = document.querySelector('#creerfichier');
    const zonetexte = editor;
    const save = document.querySelector('.block-bouton');
    document.querySelector('.fichier.nom').style.display='none';
    document.querySelector('.fichier.nom').innerHTML=``;
    zonetexte.setValue("");
    save.innerHTML='';
    save.innerHTML+=`<div class="savebutton" onclick="getdossier(event)"><div class="text icon"><i class="fa-solid fa-floppy-disk"></i></div><div class="text save">Enregistrer sous</div></div>`
    changement();
}


async function listfichier(){
    var tab;
    var idprop=usrStore.id;
    idsalon=salonStore.id;
    const f = document.querySelector('#zonefichier');
    f.innerHTML = '';
    tab= await propfichier();
    await fetch('/allfichier', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ idprop: idprop, idsalon: idsalon })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success){
            let c=0;
            data.info.forEach(fichier => {
                c=0;
                if(Object.keys(tab).length==0){
                    //console.log("ça passe");
                    const nomfichier = `${fichier.nom}.${fichier.extention}`;
                    f.innerHTML += `<div class='fichier' onclick="openf('${nomfichier}')">${fichier.nom}</div>`;
                }else{
                    tab.forEach(file=>{
                        if(file.id==fichier.id){ c+=1;}
                    });
                    if(c>0){
                        const nomfichier = `${fichier.nom}.${fichier.extention}`;
                        f.innerHTML += `<div class="block-fichier"><div class='fichier' onclick="openf('${nomfichier}')">${fichier.nom}</div><div class="bar icon" onclick="verifsupfichier(${fichier.id},'${nomfichier}')"><i class="fa-solid fa-trash"></i></div></div>`;
                    }
                }

            });
        }
        
    });/*
    .catch(error => {
        console.error('Erreur de création de fichier :', error);
    });*/
    changement();
}

function sendMsg(){
    const id=usrStore.id;
    const messageInput = document.querySelector('#sendmsg');
    const message = messageInput.value;
    const idsalon = salonStore.id;
    const date = formatDate();
    if(message){
        socket.emit('send message',{id,idsalon,message,date});
        messageInput.value='';
    }else{
        //alert('Veuillez entrer un message');
    }
    changement();
}

function affichemsg(msg){
    const block = document.querySelector('.block-message');
    //const element = document.createElement('div');<div>${msg.id}</div>
    block.innerHTML+=`<div class="msg">${msg.msg}</div>`;
    //block.appendChild(element);
    block.scrollTop=block.scrollHeight;
    changement();
}

function affichemsg1(msg){
    const block = document.querySelector('.block-message');
    //const element = document.createElement('div');
    //element.innerHTML=`<div>${msg.id}</div><div>${msg.contenu}</div>`;
    //block.appendChild(element);
    let d=formatDate(msg.date);
    if(msg.id!=usrStore.id){
        block.innerHTML+=`<div class="msg left"><div class="msg pseudo">${msg.prenom} ${msg.nom}</div><div class="msg contenu">${msg.contenu}</div><div class="msg date">${d}</div></div>`;
    }else{
        block.innerHTML+=`<div class="msg right"><div class="msg pseudo">${msg.prenom} ${msg.nom}</div><div class="msg contenu">${msg.contenu}</div><div class="msg date">${d}</div></div>`;
    }
    
    block.scrollTop=block.scrollHeight;
    changement();
}

/*************************************************************************** */
// Fichiers
/************************************************************************** */

async function Enfichier(nom,extension){
    const idsalon=salonStore.id;
    const idprop=usrStore.id;

    await fetch('/fichier', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ idprop: idprop, idsalon: idsalon, nom : nom, extension: extension })
    })
    .then(response => response.json())
    .then(data => {
    });/*
    .catch(error => {
        console.error('Erreur de creation de fichier :', error);
    });*/
    changement();
}

function nonenr(){
    document.querySelector('.create-file').style.display=`none`;
    changement();
}

async function getdossier(event){
    //const ecrit=document.querySelector('textarea#creerfichier').value;
    const ecrit = editor.getValue();
    //document.querySelector('#enr').onclick=
    event.preventDefault();
    document.querySelector('.create-file').style.display=`flex`;
    
    document.querySelector('.response.enr').innerHTML=`<div class="button oui" onclick="savef('non')">Enregistrer</div>
                    <div class="button non" onclick="nonenr()">Annuler</div>`;
    
    /*
    try{
        const fileHandle = await window.showSaveFilePicker({
            suggestedName: 'nouveau-fichier.txt',
            types: [{
                description: 'Text Files',
                accept: { 'text/plain': ['.txt'] }
            }]
        });
        const Nom = fileHandle.name;
        const partie = Nom.split('.');
        const extension = partie.pop();

        await Enfichier(partie[0],extension);
        console.log(`Nom du fichier : ${Nom}`);
        console.log(`Extension du fichier : ${extension}`);
        const writable = await fileHandle.createWritable();
        await writable.write(ecrit);
        await writable.close();

        //alert('Fichier enregistré avec succès !');

    }catch(err){
        console.log('Erreur lors de la sauvegarde : ',err);
    }*/
    //listfichier();
}
async function compiler(nom){
    console.log(nom);
    savef(nom);
    const conso = document.querySelector('.zoneconsole');
    conso.innerHTML='';
    const data = await fetch('/console', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nom }) 
    })
    .then(response=>response.json())
    .then(data=>{
        if(data.success){
            const tableau = data.donnee.split('\r\n');
            for(let i = 0; i < tableau.length ; i++){
                conso.innerHTML+=`<div class="success">${tableau[i]}</div>`;
            }
        }else{
            const tableau = data.donnee.split('\r\n');
            for(let i = 0; i < tableau.length ; i++){
                conso.innerHTML+=`<div class="success">${tableau[i]}</div>`;
            }
        }
    });
    changement();
}
/*
async function compiler(nom){
    console.log(nom);
    const conso = document.querySelector('.zoneconsole');
    conso.innerHTML='';
    await fetch('/api/python-message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nom }) 
    })
    .then(response=>response.json())
    .then(data=>{
        console.log(data.donnee);
        const mess = data.pythonMessage.split('undefined');
        console.log(mess);
        for(let i = 0; i < mess.length; i++){
            conso.innerHTML+=`<div class="success">${mess[i]}</div>`;
            conso.innerHTML+=`<input type="text" id="userResponse${i}" required>`;
        }
        
        const userInput = document.querySelector('#userResponse');
        userInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') { 
                event.preventDefault(); 
                //sendResponse(userInput.value);
                console.log(userInput.value);
                reponse(nom,userInput.value);
            }
        });
    }).catch(error =>{
        console.log("Erreur : "+error);
    });

}

async function reponse(nom,valeur){
    const conso = document.querySelector('.zoneconsole');
    await fetch('/api/python-message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nom: nom, valeur: valeur }) 
    })
    .then(response=>response.json())
    .then(data=>{
        console.log(data.donnee);
        conso.innerHTML+=`<div class="resultats">${data.pythonResult}</div>`;
    }).catch(error =>{
        console.log("Erreur : "+error);
    });
}*/

function deconnex(){
    inscrire.style.display='none';
    connecter.style.display='flex';
    accueil.style.display='none';
    usrStore={};
    salonStore={};
    localStorage.clear();
    socket.emit('desconnect',usrStore.id);
    
}

const msgInput = document.querySelector('#sendmsg');
msgInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { 
        event.preventDefault(); 
        sendMsg();
    }
});

if(localStorage.getItem("user")!=null){
    usrStore = JSON.parse(localStorage.getItem("user"));
    if(localStorage.getItem("app")!=null){
        appStore = JSON.parse(localStorage.getItem("app"));
        switch(appStore.location.page){
        
            case 'accueil':
                switch(appStore.location.mode){
                    case 'ins':
                        Inscription();
                        break;
                    case 'con':
                        connect();
                        break;
                }
                break;
            case 'menu':
                switch(appStore.location.mode){
                    case 'salon':
                        menu();
                        break;
                }
                break;
        }
    }else{
        Inscription();
    }
}else{
    connect();
}